## [1.0.0] - 26th June, 2020.

Initial release.
Features:

- Flutter skeleton loader with everything customizable, from the colors to the layout

## [1.0.1] - 28th June, 2020.

- Update Readme File
- Improve Performance & Optimized

## [1.0.2] - 3rd July, 2020.

- Add SkeletonGridLoader
- Update Example app
- Update Readme File
- Improve Performance & Optimized

## [1.0.2+1] - 4th July, 2020.

- Updated SkeletonGridLoader

## [1.0.2+2] - 12th November, 2020.

- Fix typo issue (Changed property hightlightColor to highlightColor)

## [1.0.2+3] - 8th March, 2021.

- Add Support for `childAspectRatio` on SkeletonGridLoader

## [2.0.0+4] - 6th July, 2021.

- Migrate Package to support null-safety