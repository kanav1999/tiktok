// import 'dart:ui';

class UploadFile {
  String variableName = "";
  String filePath = "";
  String fileName = "";

  UploadFile({this.variableName = "", this.filePath = "", this.fileName = ""});
}
