String appName = "Leuke";
String baseUrl = "https://leuke.unifydemos.com/";
String streamServerUrl = "wss://webrtc.unifysofttech.in:5443/WebRTCAppEE/websocket";
String pusherKey = "f6db19e9525c26c8fdba";
String pusherAppCluster = "ap3";
String apiUser = "USER";
String apiKey = "KEY";
