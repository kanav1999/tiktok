enum ItemType {
  image,
  text,
  video,
  // gif,
}

enum PaintingType { pen, marker, neon }

enum TextAnimationType { none, fade, typer, typeWriter, scale, colorize, wavy, flicker }
