## 0.0.4
- Updated README

## 0.0.3
- Updated README and pubspec.yaml

## 0.0.2
- Added Example project
- Updated README with better code sample and GIF

## 0.0.1
- Initial release