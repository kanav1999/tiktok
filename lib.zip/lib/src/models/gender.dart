class Gender {
  const Gender(this.value, this.name);

  final String name;
  final String value;
}
