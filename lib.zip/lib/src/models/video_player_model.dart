import 'package:video_player/video_player.dart';

class VideoPlayerModel {
  VideoPlayerController? videoCon;
  String type = "";
  VideoPlayerModel({this.videoCon, this.type = ""});
}
